package com.capg.dao;

import org.springframework.data.repository.CrudRepository;

import com.capg.bean.Product;

public interface ProductRepository extends CrudRepository<Product,Integer> {

}
