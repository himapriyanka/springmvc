package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.capg.bean.Product;
import com.capg.service.IProductService;


@Controller
public class ProductController {
	@Autowired
	IProductService service;
	
	 @GetMapping("/addDetails")
	    public String add() {
	        return "addProduct";
	    }
	@GetMapping("/addDetails/added")
	@ResponseBody
	public Product addProduct(Product prod) {
		
		System.out.println(prod);
		service.addProduct(prod);
		return prod;
	}
	//RETIRVE ALL
		@GetMapping("/all")
		public ModelAndView allProduct() {
			ModelAndView mv=new ModelAndView("all");
			List<Product> prodlist=service.findAll();
			mv.addObject("allproduct",prodlist);
			return mv;
		}
	
}
