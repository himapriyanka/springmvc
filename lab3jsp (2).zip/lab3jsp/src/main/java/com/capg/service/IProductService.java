package com.capg.service;

import java.util.List;

import com.capg.bean.Product;

public interface IProductService {
	public List<Product> findAll();
	
	public Product addProduct(Product prod);



}
