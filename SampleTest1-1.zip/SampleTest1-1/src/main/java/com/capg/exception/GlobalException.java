/*package com.capg.exception;

import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.capg.bean.ErrorInfo;

 

@ControllerAdvice
public class GlobalException extends Exception {
    @ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Product with given id not present")
    @ExceptionHandler(value= {Exception.class})
    protected ErrorInfo handleConflict(Exception e, HttpServletRequest req)
    {
        String message=e.getMessage();
        String uri=req.getRequestURL().toString();
        return new ErrorInfo(uri,message);
    }
}*/