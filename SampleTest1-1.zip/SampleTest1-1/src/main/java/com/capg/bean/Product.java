package com.capg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

 

import org.springframework.stereotype.Component;

 

@Entity
@Component
public class Product {
    @Id
    
    @NotNull(message="Id cannot be empty")
    private int pId;
    @NotNull(message="Name cannot be empty")
    @Size(min=3,max=20)
    private String pName;
    @Max(value=90000,message="Price cannot exceed 90000")
    private double price;
    @Size(min=10,max=10)
    private String mobNo;
    public int getpId() {
        return pId;
    }
    public void setpId(int pId) {
        this.pId = pId;
    }
    public String getpName() {
        return pName;
    }
    public void setpName(String pName) {
        this.pName = pName;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public String getMobNo() {
        return mobNo;
    }
    public void setMobNo(String mobNo) {
        this.mobNo = mobNo;
    }
    @Override
    public String toString() {
        return "Product [pId=" + pId + ", pName=" + pName + ", price=" + price + ", mobNo=" + mobNo + "]";
    }

}