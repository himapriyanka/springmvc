package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Product;

import com.capg.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	IProductService service;
	
	 @GetMapping("/products")
	    public List<Product> diaplayAllProducts()
	    {
	        return service.displayAllProducts();

	    }
	 
	 @PostMapping(path="/product", consumes= "application/json")
		public Product addProduct(@RequestBody Product pro)
		{
			return service.addProduct(pro);
		}
		
	 @PutMapping(path="/product",consumes="application/json")
		public Product updateProduct(@RequestBody Product pro)
		{
			return service.updateProduct(pro);
		}
		
	 @DeleteMapping(path="/product/{pid}")
		public void deleteProductById(@PathVariable int pid)
		{
			service.deleteProductById(pid);
			
		}
}
