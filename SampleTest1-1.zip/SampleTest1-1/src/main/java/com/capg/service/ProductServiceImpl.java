package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.capg.bean.Product;

import com.capg.dao.ProductRepository;

@Service
public class ProductServiceImpl implements IProductService{

	 @Autowired
	 ProductRepository repo;
	 
	 @Override
	    public List<Product> displayAllProducts() {
	      
	        return repo.findAll();  
	    }
	 
	 @Override
	 public Product addProduct(Product pro) {
			// TODO Auto-generated method stub
			
			return repo.save(pro);
		}

	@Override
	public Product updateProduct(Product pro) {
			// TODO Auto-generated method stub
			return repo.save(pro);
		}
	
	@Override
	public void deleteProductById(@PathVariable int pid) {
		repo.deleteById(pid);
		// TODO Auto-generated method stub
		
	}
}
