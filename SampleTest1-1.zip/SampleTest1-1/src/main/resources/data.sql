insert into product values(1,'Laptop',50000,9988776655);
insert into product values(2,'Mobile',17000,9700123456);
insert into product values(3,'AC',34000,8877994433);
insert into product values(4,'Washing Machine',23000,9977668844);