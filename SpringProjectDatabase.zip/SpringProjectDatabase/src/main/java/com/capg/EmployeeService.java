/*package com.capg;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class EmployeeService {
@Autowired
static
DAORepository daoRepository;
public List<Employee> getAllEmployee(){
	List<Employee> employees= new ArrayList<Employee>();
	daoRepository.findAll().forEach(employee-> employees.add(employee));
	return employees;
}
public static Employee getEmployeeById(int id) {
    return daoRepository.findById(id).get();


}
}







//@Service
//public class PersonService {
//
//    @Autowired
//    PersonRepository personRepository;
//
//    public List<Person> getAllPersons() {
//        List<Person> persons = new ArrayList<Person>();
//        personRepository.findAll().forEach(person -> persons.add(person));
//        return persons;
//    }*/