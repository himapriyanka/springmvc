package com.capg;

import java.util.List;

import org.apache.catalina.startup.ClassLoaderFactory.Repository;
import org.h2.server.web.WebServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class EmployeeController {
	@Autowired
	DAORepository repo;
	
	@GetMapping("/")
	public String form() {
		return "NewFile";
	}
	
	@GetMapping("/display")
	public String save(Employee emp, Model model) {
		model.addAttribute("emp",emp);
		 repo.save(emp);
		return "display";
		
	}


}
