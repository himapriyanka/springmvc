package com.capg;

 

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

 

@Component
@Entity
@Table(name="Employee")
public class Employee 
{
	@Id
	@GeneratedValue
    private int eid;
    private String ename;
    private double salary;
    
    
    public int getEid() {
        return eid;
    }
    public void setEid(int eid) {
        this.eid = eid;
    }
    public String getEname() {
        return ename;
    }
    public void setEname(String ename) {
        this.ename = ename;
    }
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    @Override
    public String toString() {
        return "Employee Details: [eid=" + eid + ", ename=" + ename + ", salary=" + salary + "]";
    }
    
    
    
    

 

}