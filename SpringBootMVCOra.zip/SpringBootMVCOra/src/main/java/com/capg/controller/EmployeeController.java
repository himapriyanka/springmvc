
    
package com.capg.controller;


import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


import com.capg.beans.Employee;

import com.capg.exception.EmployeeExp;
import com.capg.service.IEmployeeService;




@RestController
public class EmployeeController 
{
    @Autowired
    IEmployeeService service;
    
    
    /*@GetMapping("/employee/{eid}" )
    public String getEmployeeById(@PathVariable int eid)
    {
        Employee emp=service.getEmployeeById(eid);
        return emp.toString();
    }*/
    
    
     @GetMapping(path="/employees",produces= {"application/xml"})
        public List<Employee> getAllEmployee() {
            
        return   service.getAllEmployee();
        
    } 
    





    @DeleteMapping(path="/employee/{eid}")
        public void deleteEmployeeById(@PathVariable int eid) {
    	
    	
            
             service.deleteEmployeeById(eid);
            
            
        }
    @PostMapping(path="/employee",consumes= {"application/json"})//explicit
    public Employee addEmployee(@RequestBody Employee emp)//json starting from request body
    {
         return service.addEmployee(emp);
        
    }
    
    @PutMapping(path="/employee",consumes="application/xml")
    public Employee updateEmployee(@RequestBody Employee emp) {
        return service.updateEmployee(emp);
    }
     
    @GetMapping("/employeesalary/{salary}" )
    public List<Employee> getEmployeeBySalary(@PathVariable double salary) throws EmployeeExp
    {
        List<Employee> list=service.getEmployeeBySalary(salary);
        if(list .size()==0) {
            throw new EmployeeExp();
        }
        return list;
    }
    
    @GetMapping(path="/employeerange")
    public List<Employee> getEmployeeByRange() {
        List<Employee> list = service.getEmployeeByRange();
        return list;
    }
    
    @GetMapping(path="/employee/{eid}")
    public ResponseEntity getEmployeeById(@PathVariable int eid) {
        Employee emp=service.getEmployeeById(eid);
        return new ResponseEntity<>("Successful",HttpStatus.OK);
    }
    /*@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Employee with this id not present")
    @ExceptionHandler({EmployeeExp.class})
    public void handleException() {
        
    }*/
    
}
 








