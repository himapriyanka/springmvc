package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "transactiondetails")

public class TransEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TransId")
	private long transId;

	@Column(name = "InitialAcc")
	private long baccInitial;
	@Column(name = "FinalAcc")
	private long baccFinal;
	@Column(name = "TransType")
	private String transMetd;
	@Column(name = "Amountused")
	private int transBal;
	@Column(name = "Date1")
	private String transdate;

	@ManyToOne
	private BankEntity bank;

	public BankEntity getBank() {
		return bank;
	}

	public void setBank(BankEntity bank) {
		this.bank = bank;
	}

	public TransEntity(long transId, long baccInitial, long baccFinal, String transMetd, int transBal,
			String transdate) {
		super();
		this.transId = transId;
		this.baccInitial = baccInitial;
		this.baccFinal = baccFinal;
		this.transMetd = transMetd;
		this.transBal = transBal;
		this.transdate = transdate;
	}

	public TransEntity() {
		super();
	}

	@Override
	public String toString() {
		return "Transactions done  :: \n transId = " + transId + "\n  Account Number=" + baccInitial
				+ "\n  Account received number = " + baccFinal + "\n  type of Transaction =  " + transMetd
				+ "\n  Amount used =" + transBal + "\n  Transaction date=" + transdate + "";
	}

	public long getTransId() {
		return transId;
	}

	public void setTransId(long transId) {
		this.transId = transId;
	}

	public long getBaccInitial() {
		return baccInitial;
	}

	public void setBaccInitial(long baccInitial) {
		this.baccInitial = baccInitial;
	}

	public long getBaccFinal() {
		return baccFinal;
	}

	public void setBaccFinal(long baccFinal) {
		this.baccFinal = baccFinal;
	}

	public String getTransMetd() {
		return transMetd;
	}

	public void setTransMetd(String transMetd) {
		this.transMetd = transMetd;
	}

	public int getTransBal() {
		return transBal;
	}

	public void setTransBal(int transBal) {
		this.transBal = transBal;
	}

	public String getTransdate() {
		return transdate;
	}

	public void setTransdate(String transdate) {
		this.transdate = transdate;
	}

}
