package com.cap.exception;

public class DataNotFoundException extends Exception{
	public DataNotFoundException(String e)
	{
		super(e);
	}
	public DataNotFoundException()
	{
		super();
	}

}
