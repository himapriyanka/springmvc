package com.java.parallelUI;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import com.java.parallelBean.Bean;
import com.java.parallelDAO.AccountNotFoundException;
import com.java.parallelservices.Service;
public class parallelUI {
	static Scanner sc=new Scanner(System.in);
	static long phoneno;
	public static void main(String[] args) {
		 Service s=new Service();
		long bacc;
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("*************Welcome*************");
			System.out.println("Enter 1 for create account\nEnter 2 for Show Balance\nEnter 3 for Deposit");
			System.out.println("Enter 4 for withdraw\nEnter 5 for fund transfer\nEnter 6 for print Transaction");
			System.out.println("Enter 7 for exit");	
			System.out.println("enter the stage number");
			int n=sc.nextInt();
			switch(n) {
			case 1:  			                                                   //Create Account
			 		 System.out.println("Enter name");
			 		 String name = nameCheck(sc.next());
			 		 System.out.println("enter dob");
			 		 String dob= dateCheck(sc.next());
			 		 System.out.println("Enter account password");
			 		 String password=passwordCheck(sc.next());
			 		 System.out.println("enter phoneno");
			 		 long phoneno1 =sc.nextLong();
			 		long phoneno= numbercheck( phoneno1);
			 		 long intialBal=20000;
			 		long accNumb=phoneno+1000;
			 		 Bean b=new Bean(name,dob,password, intialBal,phoneno,accNumb);
			 		 long accNum=s.service(b);
			 		System.out.println("Account number is  "  +accNum);
			 		 break;		
		    case 2:			    													      //Show Balance
				System.out.println("Account Number");  
				long bacc11=sc.nextLong();
				System.out.println("Enter account password");
		 		String password1= sc.next();
		 		 try {	
				long balance=s.showbalance(bacc11,password1);
				System.out.println("bal :"+balance); 
		 		 }
		 		 catch(AccountNotFoundException exception)
		 		 {
		 		 System.out.println(exception.getMessage());
		 		 }
				break;	
			case 3: 															            //Deposit 
				System.out.println("enter account number");
				long account2=sc.nextLong();
				System.out.println("enter password");
				String password2=sc.next();
				boolean val1=s.validation(account2, password2);
						if(val1) {					
				System.out.println("enter deposit amount");
				long dep1=sc.nextLong();
				long al1=s.deposit(account2,password2,dep1);
				System.out.println("balance after deposit");
				System.out.println(al1);
						}
						else {
							System.out.println("it is not valid number");
						}
				break;
			case 4: 															  			   //Withdraw
				System.out.println("enter account number");
				long account3=sc.nextLong();
				System.out.println("enter password");
				String password3=sc.next();
				boolean val2=s.validation(account3,password3);
				if(val2) {
					
				System.out.println("enter withdraw amount");
				long wit1=sc.nextLong();
				long w=s.withdraw(account3,password3,wit1);
				System.out.println("balance after withdraw");
				System.out.println(w);
				}
				else {
					System.out.println("it is not valid number");
				}
				break;
			case 5:																				//Fund Transfer
				System.out.println("enter account1 to account2");
				long account4=sc.nextLong();
				System.out.println("enter  account2 from account1");
				long account5=sc.nextLong();
				System.out.println("enter password1");
				String password4=sc.next();				
				boolean valid =s.validation1(account4,password4,account5);
				if(valid) {
					System.out.println("account is valid and password is correct");
					System.out.println("enter the fund amount");
					long f1=sc.nextLong();
					long bal2=s.fund(account4, account5, password4, f1);
					System.out.println("amount 1 balance ");
					System.out.println(bal2);
				}
				else
				{
					System.out.println("enter valid account number and password");
				}
				break;
			case 6:                                                                       //Print Transactions
				System.out.println("account number");
				long acc=sc.nextLong();
				List aq1=s.trans();
				System.out.println(aq1);
				break;
			case 7:																		     //Exit
				System.out.println("thank you");
				break;
			}	
			}
	}
public static long numbercheck(long phoneno1)                    
{	
	if(String.valueOf(phoneno1).length()==10)
	{
		System.out.println("your number is correct");		
	}
	else
	{		
		System.out.println("enter valid mobile number");
		phoneno1=sc.nextLong();
	}
	return phoneno1;
}
public static String nameCheck(String name)
{
	while(true) {
	if(Pattern.matches("([A-Z][a-zA-Z]*)",name))
	{
	
		return name;
	}
	else {
		System.out.println("please enter the valid name");
		System.out.println("enter the name again");
		 name=sc.next();
	}
}}
public static String dateCheck(String dob)
{		
		if(Pattern.matches("[0-9]{8}",dob))
		{
		return dob;
	   }
		else
		{
			System.out.println("please enter valid date of birth");
			System.out.println("enter the date of birth again");
			dob=sc.next();
		}
		return dob;
}
public static String passwordCheck(String password)
{		
		if(String.valueOf(password).length()==8 && password.matches("[A-Z]"))
		{
		return password;
	   }
		else
		{
			System.out.println("please enter mininum 8 characters");
			password=sc.next();
		}
		return password;
}
}


			 	