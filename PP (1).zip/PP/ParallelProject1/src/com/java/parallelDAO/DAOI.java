package com.java.parallelDAO;

import com.java.parallelBean.Bean;

public interface DAOI {
	public long service1(Bean b) ;
	public long showbalance(long bacc2,String password1);
	public long deposit1(long account2, String password2, long dep1);
	public long withdraw(long account3, String password3, long w1);
	public long fund(long account4, long account5, String password4, long f1);
	public boolean validation(long account4, String password4);
	public boolean validation1(long account4, String password4, long account5);
}
