package com.capg.service;

import java.util.List;

import com.capg.bean.Product;

public interface IProductService {
	public Product add(Product pro);
	
	public Product fetch(int pid);
	
	public List<Product> display();
	
	public void delete(int id);
	
	public Product update(Product pro);

}
