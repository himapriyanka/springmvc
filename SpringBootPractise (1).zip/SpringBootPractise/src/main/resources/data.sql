insert into Product values(1,9988776655,'Laptop',50000);
insert into Product values(2,9700123456,'Mobile',17000);
insert into Product values(3,8877994433,'Ac',34000);
insert into Product values(4,9977668844,'Washing machine',23000);