package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.pojo.Trainee;
import com.example.demo.service.ITraineeService;

@Controller
public class TraineeController {
	
	String name;
	
	@Autowired
	ITraineeService service;
	
	@GetMapping("/")
	public String login() {
		return "login";
	}
	
	@GetMapping("/management")
	public String management(@RequestParam("uname") String uname) {
		this.name=uname;
		System.out.println(uname);
		return "management";
	}
	
	@GetMapping("/addDetails")
	public String add() {
		return "addTrainee";
	}
	
	@GetMapping("/addDetails/added")
	@ResponseBody
	public Trainee addTrainee(Trainee trainee) {
		//ModelAndView mv= new ModelAndView("traineeData");
		//mv.addObject("empKey",trn);
		System.out.println(trainee);
		service.add(trainee);
		return trainee;
	}
	
	
	//DELETE TRAINEE
	@GetMapping("/delete")
	public String delete() {
		return "delete";
	}
	@GetMapping("/delete/deleteConfirm")
	public ModelAndView deleteconfirm(@RequestParam("id") int id) {
		ModelAndView mv=new ModelAndView();
		Trainee trn=service.find(id);
		mv.addObject("traineeObj",trn);
		mv.setViewName("deleteconfirm");
		return mv;
	}
	@GetMapping("/delete/deleted")
	@ResponseBody
	public String deleted(@RequestParam("id") int id) {
		service.delete(id);
		return "Trainee Deleted Successfully";
	}
	
	
	//MODIFY
	@GetMapping("/modify")
	public String update() {
		return "update";
	}
	@GetMapping("/modify/updateConfirm")
	public ModelAndView updateconfirm(@RequestParam("id") int id) {
		ModelAndView mv=new ModelAndView();
		Trainee trn=service.find(id);
		mv.addObject("traineeObj",trn);
		mv.setViewName("updateconfirm");
		return mv;
	}
	@GetMapping("/modify/updated")
	@ResponseBody
	public String updated(Trainee trn) {
		service.update(trn);
		return "Updated Successfully";
	}
	
	
	//RETRIEVE
	@GetMapping("/retrieve")
	public String retrive(){
		return "retrieve";
	}
	@GetMapping("/retrieve/data")
	public ModelAndView retrievedata(@RequestParam("id") int id) {
		ModelAndView mv=new ModelAndView();
		Trainee trn=service.find(id);
		mv.addObject("traineeObj",trn);
		mv.setViewName("traineedata");
		return mv;
	}
	
	
	//RETIRVE ALL
	@GetMapping("/all")
	public ModelAndView allTrainee() {
		ModelAndView mv=new ModelAndView("all");
		List<Trainee> trnlist=service.findAll();
		mv.addObject("alltrainee",trnlist);
		return mv;
	}

}
