package com.capg.service;

import java.util.List;

import com.capg.beans.Employee;

public interface IEmployeeService 
{
	public Employee getEmployeeById(int eid);
	public List<Employee> getAllEmployee();
	
	public void deleteEmployeeById(int eid);
	
	public Employee addEmployee(Employee emp);
	
	public Employee updateEmployee(Employee emp);
	
	public List<Employee> getEmployeeBySalary(double salary);
	
	public List<Employee> getEmployeeByRange();
}
