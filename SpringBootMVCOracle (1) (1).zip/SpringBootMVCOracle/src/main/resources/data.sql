insert into employee values(101,'rasu',78000);
insert into employee values(102,'sri',80000);
insert into employee values(103,'anvi',78000);
insert into employee values(104,'aishu',78000);